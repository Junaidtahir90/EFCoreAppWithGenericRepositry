﻿
namespace EFCoreDemoApp.Models
{
    public class ResultDTO
    {
        public string Name { get; set; }
        public decimal Salary { get; set; }
        public int count { get; set; }
    }
}
